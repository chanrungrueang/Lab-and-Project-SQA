package code;

public class Multiplication {
	
	public int multiply(int number1, int number2)
	{
		return number1*number2;
	}
	
	public int square(int number)
	{
		return number*number;
	}
}
