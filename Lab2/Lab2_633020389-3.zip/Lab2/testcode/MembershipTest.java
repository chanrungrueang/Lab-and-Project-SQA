package testcode;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import code.Membership;

class MembershipTest {
	Membership Ms = new Membership();
	@Test
	@BeforeEach
	@DisplayName("TS01 : 0 purchase, 0 invitefriend, 0 joinevent ,Expected Result = 0")
	void test1() {
		assertEquals(0,Ms.calculatePoint(0, 0, 0));
	}
	@Test
	@DisplayName("TS01 : 40 purchase, 40 invitefriend, 40 joinevent ,Expected Result = 120")
	void test2() {
		assertEquals(120,Ms.calculatePoint(40, 40, 40));
	}
	@Test
	@DisplayName("TS01 : 10 purchase, 10 invitefriend, 10 joinevent ,Expected Result = 30")
	void test3() {
		assertEquals(30,Ms.calculatePoint(10, 10, 10));
	}
	@Test
	@DisplayName("TS01 : 10 purchase, 15 invitefriend, -26 joinevent ,Expected Result = -1")
	void test4() {
		assertEquals(-1,Ms.calculatePoint(10, 15, -26));
	}
	@Test
	@DisplayName("TS01 : 50 purchase, -1 pointFinal, 40 pointCollected , Expected Result = 89")
	void test5() {
		assertEquals(-1,Ms.calculatePoint(50, -1, 40));
	}
	@Test
	@DisplayName("TS02 : 0 purchase, 0 invitefriend, 0 joinevent ,Expected Result = Zinc")
	void test6() {
		assertEquals("Zinc",Ms.checkMembershipStatus(0));
	}
	@Test
	@DisplayName("TS02 : 40 purchase, 40 invitefriend, 40 joinevent ,Expected Result = Platinum")
	void test7() {
		assertEquals("Platinum",Ms.checkMembershipStatus(120));
	}
	@Test
	@DisplayName("TS02 : purchase, 10 invitefriend, 10 joinevent ,Expected Result = Copper")
	void test8() {
		assertEquals("Copper",Ms.checkMembershipStatus(30));
	}
	@Test
	@DisplayName("TS02 : purchase, 15 invitefriend, -26 joinevent ,Expected Result = Invalid")
	void test9() {
		assertEquals("Invalid",Ms.checkMembershipStatus(-1));
	}
	@Test
	@DisplayName("TS02 : purchase, -1 pointFinal, 40 pointCollected , Expected Result = Gold")
	void test10() {
		assertEquals("Gold",Ms.checkMembershipStatus(89));
	}
}
