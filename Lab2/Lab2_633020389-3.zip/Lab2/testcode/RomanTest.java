package testcode;
import static org.junit.Assert.assertTrue;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import code.RomanNumerals;


class RomanTest {
	RomanNumerals rm = new RomanNumerals();
	@Test
	@DisplayName("Test1Digit I ,Expected Result = 1")
	@BeforeEach
	void Test1Digit() {
		assertEquals(1,rm.convertRomanNumToInt("I"));
	}
	@Test
	@DisplayName("Test2Digit IX ,Expected Result = 9")
	void Test2Digit() {
		assertEquals(9,rm.convertRomanNumToInt("IX"));
	}
	@Test
	@DisplayName("Test2Digit XI ,Expected Result = 11")
	void Test2Digit1() {
		assertEquals(11,rm.convertRomanNumToInt("XI"));
	}
	@Test
	@DisplayName("Test2Digit II ,Expected Result = 2")
	void Test2Digit2() {
		assertEquals(2,rm.convertRomanNumToInt("II"));
	}
	@Test
	@DisplayName("Test3DigitSameX LXX ,Expected Result = 70")
	void Test3DigitSameX() {
		assertEquals(70,rm.convertRomanNumToInt("LXX"));
	}
	@Test
	@DisplayName("Test3Digit LXI ,Expected Result = 61")
	void Test3Digit() {
		assertEquals(61,rm.convertRomanNumToInt("LXI"));
	}
}
