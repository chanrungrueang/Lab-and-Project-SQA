package Code;

public class Numbers {
	
	public static boolean isOddNumber(int number) {
        return number % 2 != 0;
    }
	
	public static boolean isEvenNumber(int number) {
        return number % 2 == 0;
    }

}
