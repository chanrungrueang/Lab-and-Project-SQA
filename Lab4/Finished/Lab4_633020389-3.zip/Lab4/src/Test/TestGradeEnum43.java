package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import Code.GradeEnum;

class TestGradeEnum43 {
	GradeEnum ge;
	@DisplayName("TS001")
	@ParameterizedTest
	@CsvFileSource(files = "src/Test/resource/4.3.1.csv", numLinesToSkip = 1)
	void TS001(int sectionA, int sectionB, int scoreFinal, String expect) {
		ge = new GradeEnum(sectionA, sectionB, scoreFinal);
		String result = ge.showResult(ge.classify());
		assertEquals(expect, result);
	}
	@DisplayName("TS002")
	@ParameterizedTest
	@CsvFileSource(files = "src/Test/resource/4.3.2.csv", numLinesToSkip = 1)
	void TS002(int sectionA, int sectionB, int scoreFinal, String expect) {
		ge = new GradeEnum(sectionA, sectionB, scoreFinal);
		String result = ge.showResult(ge.classify());
		assertEquals(expect, result);
	}
	@DisplayName("TS003")
	@ParameterizedTest
	@CsvFileSource(files = "src/Test/resource/4.3.3.csv", numLinesToSkip = 1)
	void TS003(int sectionA, int sectionB, int scoreFinal, String expect) {
		ge = new GradeEnum(sectionA, sectionB, scoreFinal);
		String result = ge.showResult(ge.classify());
		assertEquals(expect, result);
	}
	@DisplayName("TS004")
	@ParameterizedTest
	@CsvFileSource(files = "src/Test/resource/4.3.4.csv", numLinesToSkip = 1)
	void TS004(int sectionA, int sectionB, int scoreFinal, String expect) {
		ge = new GradeEnum(sectionA, sectionB, scoreFinal);
		String result = ge.showResult(ge.classify());
		assertEquals(expect, result);
	}
	@DisplayName("TS005")
	@ParameterizedTest
	@CsvFileSource(files = "src/Test/resource/4.3.5.csv", numLinesToSkip = 1)
	void TS005(int sectionA, int sectionB, int scoreFinal, String expect) {
		ge = new GradeEnum(sectionA, sectionB, scoreFinal);
		String result = ge.showResult(ge.classify());
		assertEquals(expect, result);
	}
}
