package Code;

public class main {

	public static void main(String[] args) {
		ShippingPackage sp = new ShippingPackage();
		System.out.println(sp.calculate(1, 1, 0));
	}
}
