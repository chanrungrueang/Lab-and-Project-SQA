package ExTest;

import static org.junit.jupiter.api.Assertions.*;


import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import ExCode.Strings;

class ExternalMethodTest {

	 @ParameterizedTest
	 @MethodSource("ExTest.StringParameters#provideSomeStrings")
	    void testWithExternalMethodSource(String input) {
		 	assertTrue(Strings.isBlank(input));
	 }
}

class StringParameters{
	static Stream<String> provideSomeStrings() {
        return Stream.of(".", "oo", "OOO", null, "", "  ");
	}
}
