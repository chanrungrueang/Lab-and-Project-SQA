package Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import Code.Commission;

class TestCommision {
	Commission cms = new Commission();
	@ParameterizedTest
	@DisplayName("x1 = 1 16 test case")
	@MethodSource("Test_Commission_1")
	void Test1(int lock,int stock,int barrel,int total) 
	{
		assertEquals(total,cms.checkCommission(lock, stock, barrel));
	}
	@ParameterizedTest
	@DisplayName("x1 = 35 16 test case")
	@MethodSource("Test_Commission_35")
	void Test2(int lock,int stock,int barrel,int total) 
	{
		assertEquals(total,cms.checkCommission(lock, stock, barrel));
	}
	@ParameterizedTest
	@DisplayName("x1 = 0 16 test case")
	@MethodSource("Test_Commission_0")
	void Test3(int lock,int stock,int barrel,int total) 
	{
		assertEquals(total,cms.checkCommission(lock, stock, barrel));
	}
	@ParameterizedTest
	@DisplayName("x1 = 71 16 test case")
	@MethodSource("Test_Commission_71")
	void Test4(int lock,int stock,int barrel,int total) 
	{
		assertEquals(total,cms.checkCommission(lock, stock, barrel));
	}
	static Stream<Arguments>Test_Commission_1()
	{
		return Stream.of(
				Arguments.arguments(1,1,1,1000),
				Arguments.arguments(1,1,45,20500),
				Arguments.arguments(1,1,0,-1),
				Arguments.arguments(1,1,91,-1),
				Arguments.arguments(1,40,1,21900),
				Arguments.arguments(1,40,45,43900),
				Arguments.arguments(1,40,0,-1),
				Arguments.arguments(1,40,91,-1),
				Arguments.arguments(1,0,1,-1),
				Arguments.arguments(1,0,45,-1),
				Arguments.arguments(1,0,0,-1),
				Arguments.arguments(1,0,91,-1),
				Arguments.arguments(1,81,1,-1),
				Arguments.arguments(1,81,45,-1),
				Arguments.arguments(1,81,0,-1),
				Arguments.arguments(1,81,91,-1)
				);
	}
	static Stream<Arguments>Test_Commission_35()
	{
		return Stream.of(
				Arguments.arguments(35,1,1,29100),
				Arguments.arguments(35,1,45,51100),
				Arguments.arguments(35,1,0,-1),
				Arguments.arguments(35,1,91,-1),
				Arguments.arguments(35,40,1,52500),
				Arguments.arguments(35,40,45,74500),
				Arguments.arguments(35,40,0,-1),
				Arguments.arguments(35,40,91,-1),
				Arguments.arguments(35,0,1,-1),
				Arguments.arguments(35,0,45,-1),
				Arguments.arguments(35,0,0,-1),
				Arguments.arguments(35,0,91,-1),
				Arguments.arguments(35,81,1,-1),
				Arguments.arguments(35,81,45,-1),
				Arguments.arguments(35,81,0,-1),
				Arguments.arguments(35,81,91,-1)
				);
	}
	static Stream<Arguments>Test_Commission_0()
	{
		return Stream.of(
				Arguments.arguments(0,1,1,-1),
				Arguments.arguments(0,1,45,-1),
				Arguments.arguments(0,1,0,-1),
				Arguments.arguments(0,1,91,-1),
				Arguments.arguments(0,40,1,-1),
				Arguments.arguments(0,40,45,-1),
				Arguments.arguments(0,40,0,-1),
				Arguments.arguments(0,40,91,-1),
				Arguments.arguments(0,0,1,-1),
				Arguments.arguments(0,0,45,-1),
				Arguments.arguments(0,0,0,-1),
				Arguments.arguments(0,0,91,-1),
				Arguments.arguments(0,81,1,-1),
				Arguments.arguments(0,81,45,-1),
				Arguments.arguments(0,81,0,-1),
				Arguments.arguments(0,81,91,-1)
				);
	}
	static Stream<Arguments>Test_Commission_71()
	{
		return Stream.of(
				Arguments.arguments(71,1,1,-1),
				Arguments.arguments(71,1,45,-1),
				Arguments.arguments(71,1,0,-1),
				Arguments.arguments(71,1,91,-1),
				Arguments.arguments(71,40,1,-1),
				Arguments.arguments(71,40,45,-1),
				Arguments.arguments(71,40,0,-1),
				Arguments.arguments(71,40,91,-1),
				Arguments.arguments(71,0,1,-1),
				Arguments.arguments(71,0,45,-1),
				Arguments.arguments(71,0,0,-1),
				Arguments.arguments(71,0,91,-1),
				Arguments.arguments(71,81,1,-1),
				Arguments.arguments(71,81,45,-1),
				Arguments.arguments(71,81,0,-1),
				Arguments.arguments(71,81,91,-1)
				);
	}
}