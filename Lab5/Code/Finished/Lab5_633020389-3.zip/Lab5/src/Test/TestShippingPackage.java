package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import Code.ShippingPackage;

class TestShippingPackage {
	ShippingPackage sp = new ShippingPackage();
	@ParameterizedTest
	@DisplayName("ShippingPackage 10 Test Case")
	@MethodSource("ShippingPackage")
	void test(int SmallSize, int LargeSize, int Total, int Expected) {
		assertEquals(Expected, sp.calculate(SmallSize, LargeSize, Total));
	}
	static Stream<Arguments>ShippingPackage()
	{
		return Stream.of(
				Arguments.arguments(-1,1,5,-1),
				Arguments.arguments(1,-1,5,-1),
				Arguments.arguments(1,1,-5,-1),
				Arguments.arguments(1,1,20,2),
				Arguments.arguments(0,1,5,1),
				Arguments.arguments(1,0,5,1),
				Arguments.arguments(1,1,0,-1),
				Arguments.arguments(1,2,11,3),
				Arguments.arguments(5,2,10,-1),
				Arguments.arguments(10,2,10,-1)
				);
	}
}

