package Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import Test.TVPlanEdit.TVPackage;

class TVPlanTest61 {
    TVPlanEdit tvplan;
    @DisplayName("TS001")
    @ParameterizedTest
    @MethodSource("basic")
    void TS001(boolean family_sharing, boolean international_region, boolean discount,int Expected) {
        TVPackage tp = TVPackage.BASIC;
        tvplan = new TVPlanEdit(family_sharing,international_region,discount);
        double cost = tvplan.pricePerMonth(tp);
        assertEquals(Expected,cost);
    }
    @DisplayName("TS002")
    @ParameterizedTest
    @MethodSource("standard")
    void TS002(boolean family_sharing, boolean international_region, boolean discount,int Expected) {
        TVPackage tp = TVPackage.STANDARD;
        tvplan = new TVPlanEdit(family_sharing,international_region,discount);
        double cost = tvplan.pricePerMonth(tp);
        assertEquals(Expected,cost);
    }
    @DisplayName("TS003")
    @ParameterizedTest
    @MethodSource("premium")
    void TS003(boolean family_sharing, boolean international_region, boolean discount,int Expected) {
        TVPackage tp = TVPackage.PREMIUM;
        tvplan = new TVPlanEdit(family_sharing,international_region,discount);
        double cost = tvplan.pricePerMonth(tp);
        assertEquals(Expected,cost);
    }
    static Stream<Arguments>basic()
    {
    	return Stream.of(
    			Arguments.arguments(true,true,true,550),
    			Arguments.arguments(true,true,false,600),
    			Arguments.arguments(true,false,true,350),
    			Arguments.arguments(false,true,true,400),
    			Arguments.arguments(true,false,false,400),
    			Arguments.arguments(false,true,false,450),
    			Arguments.arguments(false,false,true,200),
    			Arguments.arguments(false,false,false,250)
    			);
    }
    static Stream<Arguments>standard()
    {
    	return Stream.of(
    			Arguments.arguments(true,true,true,650),
    			Arguments.arguments(true,true,false,700),
    			Arguments.arguments(true,false,true,450),
    			Arguments.arguments(false,true,true,500),
    			Arguments.arguments(true,false,false,500),
    			Arguments.arguments(false,true,false,550),
    			Arguments.arguments(false,false,true,300),
    			Arguments.arguments(false,false,false,350)
    			);
    }
    static Stream<Arguments>premium()
    {
    	return Stream.of(
    			Arguments.arguments(true,true,true,750),
    			Arguments.arguments(true,true,false,800),
    			Arguments.arguments(true,false,true,550),
    			Arguments.arguments(false,true,true,600),
    			Arguments.arguments(true,false,false,600),
    			Arguments.arguments(false,true,false,650),
    			Arguments.arguments(false,false,true,400),
    			Arguments.arguments(false,false,false,450)
    			);
    }

}