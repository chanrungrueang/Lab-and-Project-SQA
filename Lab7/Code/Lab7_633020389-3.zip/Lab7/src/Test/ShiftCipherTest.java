package Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import Code.ShiftCipher;

class ShiftCipherTest {
	
	ShiftCipher cipher = new ShiftCipher();
	@ParameterizedTest
	@CsvSource({"abc,3,invalid","@,3,invalid","XYZ,3,ABC","ABC,-3,XYZ","HIJ,3,KLM"})
	void test_shift1(String az,int number,String Expected) {
		String result = cipher.shift(az, number);
		assertEquals(Expected,result);
	}
}
