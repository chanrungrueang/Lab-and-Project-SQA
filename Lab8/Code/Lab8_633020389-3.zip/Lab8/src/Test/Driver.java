package Test;

import Code.DistanceConverter;
import Code.TemperatureConverter;
import Code.UniversalConverter;
import Code.WeightConverter;

public class Driver {

	public static void main(String[] args) {//633020389-3 ชาญรุ่งเรือง จันทวารา sec1
		UniversalConverter uc = new UniversalConverter();
		DistanceConverter dc = new DistanceConverter();
		TemperatureConverter tc = new TemperatureConverter();
		WeightConverter wc = new WeightConverter();
		
		
		System.out.println("Universal");
		double originalValue = 10.0;
		double convertedValue = 0.0;	//results of the universal converter
		String selectedChoice = "Distance";
		String from = "kilometer";
		String to = "meter";
		convertedValue = uc.convert(originalValue, selectedChoice, from, to);
		System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);
		System.out.println("---------------------------------------");

		
		originalValue = 1.0;
		convertedValue = 0.0;	
		selectedChoice = "Temperature";
		from = "C";
		to = "K";
		convertedValue = uc.convert(originalValue, selectedChoice, from, to);
		System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);
		System.out.println("---------------------------------------");
		

		originalValue = 10.0;
		convertedValue = 0.0;	
		selectedChoice = "Weight";
		from = "kilogram";
		to = "gram";
		convertedValue = uc.convert(originalValue, selectedChoice, from, to);
		System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);
		System.out.println("---------------------------------------");
		
		
		
		
		System.out.println("Distance");
		
		//Distance
		originalValue = 10.0;
		convertedValue = 0.0;	//results of the universal converter
		from = "kilometer";
		to = "meter";
		convertedValue = dc.convert(originalValue, from, to);
		double Multiplier1 = dc.getMultiplier(from, to);
		System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);
		System.out.println("Multiplier = "+Multiplier1+"\n");
		System.out.println("---------------------------------------");
		
		
		System.out.println("Temperature");
		//Temperature
		originalValue = 1.0;
		convertedValue = 0.0;	//results of the universal converter
		from = "C";
		to = "K";
		convertedValue = tc.convert(originalValue, from, to);
		System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);
		System.out.println("---------------------------------------");
				
		System.out.println("Weight");
		//Weight
		originalValue = 10.0;
		convertedValue = 0.0;	//results of the universal converter
		from = "kilogram";
		to = "gram";
		convertedValue = wc.convert(originalValue, from, to);
		double Multiplier2 = wc.getMultiplier(from, to);
		System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);
		System.out.println("Multiplier = "+Multiplier2+"\n");
		System.out.println("---------------------------------------");
				
	}

}