package Test;

import Code.DistanceConverter;

public class StubDistanceConverter extends DistanceConverter{//633020389-3 ชาญรุ่งเรือง จันทวารา sec1
	@Override
	public double convert(double distanceValue, String fromUnit, String toUnit) {
		return 10000;
	}
	@Override
	public double getMultiplier(String fromUnit, String toUnit) {
		return 1000;
		
	}
}
