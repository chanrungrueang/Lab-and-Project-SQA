package Test;

import Code.TemperatureConverter;

public class StubTemperatureConverter extends TemperatureConverter{//633020389-3 ชาญรุ่งเรือง จันทวารา sec1
	@Override
	public double convert(double tempValue, String fromUnit, String toUnit) {
		return 274.15;
	}
}
