package Test;

import Code.WeightConverter;

public class StubWeightConverter extends WeightConverter{//633020389-3 ชาญรุ่งเรือง จันทวารา sec1
	public double convert(double massValue, String fromUnit, String toUnit) {
		return 0.01;
	}
	
	public double getMultiplier(String fromUnit, String toUnit) {
		return 1.0/1000;
	}
}
