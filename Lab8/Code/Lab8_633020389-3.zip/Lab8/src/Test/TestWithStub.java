package Test;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import Code.DistanceConverter;
import Code.TemperatureConverter;
import Code.WeightConverter;

class TestWithStub {//633020389-3 ชาญรุ่งเรือง จันทวารา sec1
	StubDistanceConverter dc = new StubDistanceConverter();
	StubTemperatureConverter tc = new StubTemperatureConverter();
	StubWeightConverter wc = new StubWeightConverter();
	@Test
	public void testDistanceCovertergetMultiplier() {
		assertEquals(1000,dc.getMultiplier("Kilometer", "meter"));
	}
	@Test
	public void testDistanceCoverterConvert() {
		assertEquals(10000,dc.convert(10, "kilometer", "meter"));
	}
	@Test
	public void testTemperatureConverterConvert() {
		assertEquals(274.15,tc.convert(1,"C", "K"));
	}
	@Test
	public void testWeightConvertergetMultiplier() {
		assertEquals(1.0/1000,wc.getMultiplier("kilogram", "gram"));
	}
	@Test
	public void testWeightCoverterConvert() {
		assertEquals(0.01,wc.convert(10, "kilogram", "gram"));
	}
}
