package kku.sqa.lab.api;

import java.util.ArrayList;
import java.util.List;

public class FavoriteSong implements MusicService{//ชาญรุ่งเรือง จันทวารา 633020389-3
	private MusicService MusicService;
	public FavoriteSong(MusicService musicservice)
	{
		super();
		this.MusicService = musicservice;
	}
	public List<String> getmusic(String music) {
		List<String> musiclist = new ArrayList<String>();
		List<String> allmusiclist = MusicService.getmusic(music);
		for (String m: allmusiclist) 
			if (music == "running")
			{
				if (m.contains("Harder")) 
				{
					musiclist.add(m);
				}
			}
			else if(music == "rock")
			{
				if (m.contains("numb")) 
				{
					musiclist.add(m);
				}
			}
			else if(music == "dance")
			{
				if (m.contains("Pink")) 
				{
					musiclist.add(m);
				}
			}
		return musiclist;
	}
}