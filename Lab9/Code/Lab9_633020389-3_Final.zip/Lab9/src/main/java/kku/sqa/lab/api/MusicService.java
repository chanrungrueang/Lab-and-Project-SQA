package kku.sqa.lab.api;

import java.util.List;

public interface MusicService {//ชาญรุ่งเรือง จันทวารา 633020389-3
	public List<String> getmusic(String music);
}
