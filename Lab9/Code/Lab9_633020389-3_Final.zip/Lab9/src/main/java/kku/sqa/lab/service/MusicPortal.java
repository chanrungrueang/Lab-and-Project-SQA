package kku.sqa.lab.service;

import java.util.ArrayList;
import java.util.List;

import kku.sqa.lab.api.MusicService;

public class MusicPortal implements MusicService{//ชาญรุ่งเรือง จันทวารา 633020389-3

	public List<String> getmusic(String music) {
		List<String> getmusic = new ArrayList<String>();
		getmusic.add("Harder Better Faster Stronger,Don't Stop Believin,"
				+ "Shut Up and Dance,The Pretender,Sandstorm");
		getmusic.add("Pink venom,No Rush,"
				+ "Mean It,ILYSB");
		getmusic.add("it's My Life,numb,"
				+ "Heartache,Sweet Child O' Mine");
		return getmusic;
	}
	
}
