package kku.sqa.lab.data.stub;

import java.util.Arrays;
import java.util.List;

import kku.sqa.lab.api.MusicService;

public class StubMusicService implements MusicService{//ชาญรุ่งเรือง จันทวารา 633020389-3

	public List<String> getmusic(String music) {
		return Arrays.asList("it's My Life,numb,Heartache,Sweet Child O' Mine");
	}

}
