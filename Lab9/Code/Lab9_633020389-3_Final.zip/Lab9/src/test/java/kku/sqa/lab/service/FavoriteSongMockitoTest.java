package kku.sqa.lab.service;
import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import kku.sqa.lab.api.FavoriteSong;
import kku.sqa.lab.api.MusicService;
public class FavoriteSongMockitoTest {//ชาญรุ่งเรือง จันทวารา 633020389-3
	@Test
	public void testMockito() {
		MusicService ms = mock(MusicService.class);
		List<String> mslist = Arrays.asList("it's My Life,numb,Heartache,Sweet Child O' Mine");
		when(ms.getmusic("rock")).thenReturn(mslist);
		FavoriteSong fs = new FavoriteSong(ms);
		List<String> fslist = fs.getmusic("rock");
		assertEquals("it's My Life,numb,Heartache,Sweet Child O' Mine", fslist.get(0));	
	}
}