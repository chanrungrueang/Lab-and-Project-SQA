package kku.sqa.lab.service;

import static org.junit.Assert.assertEquals;
import java.util.List;
import kku.sqa.lab.api.*;
import kku.sqa.lab.data.stub.*;
import org.junit.Test;

public class TestStubFavoriteSong {//ชาญรุ่งเรือง จันทวารา 633020389-3
	MusicService sms = new StubMusicService();
	FavoriteSong fs = new FavoriteSong(sms);
	@Test
	public void test() {
		List<String> music = fs.getmusic("rock");
		System.out.println(sms.getmusic("rock"));
		assertEquals("it's My Life,numb,Heartache,Sweet Child O' Mine",music.get(0));
	}
}
